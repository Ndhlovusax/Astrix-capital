# Configuration constants
APP_NAME = "Astrix Capital v3"
DEFAULT_ASSETS = ["XAUUSD", "BTCUSD", "EURUSD", "SPX500", "NASDAQ"]